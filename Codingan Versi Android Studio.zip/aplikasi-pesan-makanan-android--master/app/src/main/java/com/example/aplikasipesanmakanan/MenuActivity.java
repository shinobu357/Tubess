package com.example.aplikasipesanmakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    String namaUser;
    TextView txtNama;

    FirebaseUser user;
    FirebaseAuth mAuth;

    FirebaseFirestore fireDb;

    private RecyclerView recPenyetan;
    private RecyclerView recDrinks;
    private ArrayList<Penyetan> listPenyetan;
    private ArrayList<Drinks> listDrinks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        initFab();

        fireDb = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        namaUser = user.getEmail();

        recPenyetan = findViewById(R.id.rec_penyetan);
        recDrinks = findViewById((R.id.rec_drinks));
        initDataPenyetan();
        initDataDrinks();

        recPenyetan.setAdapter(new PenyetanAdapter(listPenyetan));
        recPenyetan.setLayoutManager(new LinearLayoutManager(this));

        recDrinks.setAdapter(new DrinksAdapter(listDrinks));
        recDrinks.setLayoutManager(new LinearLayoutManager(this));

        txtNama = findViewById(R.id.txtNama);
        txtNama.setText("Hi, " + namaUser);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initFab(){
        FloatingActionButton fabCart = findViewById(R.id.fabCart);
        fabCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getBaseContext(), CartActivity.class));
            }
        });

        FloatingActionButton fabLogout = findViewById(R.id.fabLogout);
        fabLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                startActivity(new Intent(getBaseContext(), MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });
    }

    private void initDataPenyetan(){
        this.listPenyetan =  new ArrayList<>();
        listPenyetan.add(new Penyetan("Ayam Goreng", "23000", R.drawable.ayam_goreng));
        listPenyetan.add(new Penyetan("Bebek Kremez", "25000", R.drawable.bebek_kremes));
        listPenyetan.add(new Penyetan("Lele Goreng", "13000", R.drawable.lele_goreng));
        listPenyetan.add(new Penyetan("Iga Penyet", "42000", R.drawable.iga_penyet));
        listPenyetan.add(new Penyetan("Ayam Geprek", "24000", R.drawable.ayam_geprek));
        listPenyetan.add(new Penyetan("Gurame Mercon", "41000", R.drawable.gurame_mercon));
    }

    private void initDataDrinks(){
        this.listDrinks = new ArrayList<>();
        listDrinks.add(new Drinks("coffe 3", "8000", R.drawable.coffe3));
        listDrinks.add(new Drinks("coffe 4", "5000", R.drawable.coffe4));
        listDrinks.add(new Drinks("coffe 5", "7000", R.drawable.coffe5));
        listDrinks.add(new Drinks("coffe 1", "5000", R.drawable.coffee1));
        listDrinks.add(new Drinks("latte 2", "3000", R.drawable.lattee2));
        listDrinks.add(new Drinks("new coffe", "8000", R.drawable.newcoffee));
    }
}